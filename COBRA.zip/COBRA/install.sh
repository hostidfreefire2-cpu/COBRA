#!/usr/bin/env bash
# COBRA installer  -  Termux / Debian / Ubuntu / Kali
#
# What it does (nothing hidden):
#   1. installs python (+ git) if missing
#   2. copies bin/cobra.py  ->  $PREFIX/bin/cobra  (Termux)  or  ~/.local/bin/cobra  (Linux)
#   3. adds ONE marked block to ~/.bashrc (and ~/.zshrc if you use zsh)  -> banner + prompt
#   4. Termux only: installs the COBRA color theme (your old one is backed up) and hides the Termux welcome text
# It never uses sudo for COBRA itself, never changes your login shell, never deletes anything outside ~/.cobra.
set -u

SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
UPDATE=0; KEY=""
while [ $# -gt 0 ]; do
    case "$1" in
        --update) UPDATE=1 ;;
        --key) shift; KEY="${1:-}" ;;
        --key=*) KEY="${1#--key=}" ;;
    esac
    shift
done
CFG="$HOME/.cobra"
MANIFEST="$CFG/manifest"
IS_TERMUX=0; [ -d /data/data/com.termux/files/usr ] && IS_TERMUX=1
if [ "$IS_TERMUX" = 1 ]; then BIN="${PREFIX:-/data/data/com.termux/files/usr}/bin"; else BIN="$HOME/.local/bin"; fi

if [ -t 1 ]; then G=$'\e[1;92m'; C=$'\e[1;96m'; Y=$'\e[1;93m'; R=$'\e[1;91m'; D=$'\e[2m'; N=$'\e[0m'
else G=""; C=""; Y=""; R=""; D=""; N=""; fi
ok()   { printf ' %s[+]%s %s\n' "$G" "$N" "$1"; }
warn() { printf ' %s[!]%s %s\n' "$Y" "$N" "$1"; }
die()  { printf ' %s[x]%s %s\n' "$R" "$N" "$1"; exit 1; }

printf '\n %sCOBRA installer%s  %s%s%s\n\n' "$G" "$N" "$D" "$( [ "$UPDATE" = 1 ] && echo update || echo fresh install )" "$N"

[ -f "$SRC/bin/cobra.py" ] || die "bin/cobra.py not found next to install.sh"

# ---- 1. dependencies ------------------------------------------------------------------------
need_pkgs=()
command -v python3 >/dev/null 2>&1 || need_pkgs+=("python")
command -v git     >/dev/null 2>&1 || need_pkgs+=("git")
# node lets COBRA really syntax-check the JavaScript inside games/web pages (Termux only, optional)
if [ "$IS_TERMUX" = 1 ] && [ "${COBRA_SKIP_NODE:-0}" != 1 ]; then command -v node >/dev/null 2>&1 || need_pkgs+=("nodejs"); fi
if [ "$IS_TERMUX" = 1 ]; then command -v termux-open >/dev/null 2>&1 || need_pkgs+=("termux-tools"); fi
if [ "${COBRA_SKIP_DEPS:-0}" != 1 ] && [ "${#need_pkgs[@]}" -gt 0 ]; then
    if [ "$IS_TERMUX" = 1 ]; then
        ok "installing: ${need_pkgs[*]}"
        pkg install -y "${need_pkgs[@]}" >/dev/null 2>&1 || warn "pkg install failed, continuing"
    elif command -v apt-get >/dev/null 2>&1; then
        names=(); for p in "${need_pkgs[@]}"; do [ "$p" = python ] && names+=(python3) || names+=("$p"); done
        ok "installing: ${names[*]} (may ask for your password)"
        if [ "$(id -u)" -eq 0 ]; then apt-get install -y "${names[@]}" >/dev/null 2>&1 || warn "apt-get failed, continuing"
        elif command -v sudo >/dev/null 2>&1; then sudo apt-get install -y "${names[@]}" >/dev/null 2>&1 || warn "apt-get failed, continuing"
        else warn "no sudo - please install: ${names[*]}"; fi
    else
        warn "please install manually: ${need_pkgs[*]}"
    fi
fi
command -v python3 >/dev/null 2>&1 || die "python3 is required"
command -v git >/dev/null 2>&1 || warn "git not found - 'update' will not work until you install it"
ok "python $(python3 -c 'import platform;print(platform.python_version())')"

# ---- 2. program -----------------------------------------------------------------------------
mkdir -p "$BIN" "$CFG" || die "cannot create $BIN"
cp "$SRC/bin/cobra.py" "$BIN/cobra" && chmod +x "$BIN/cobra" || die "cannot write $BIN/cobra"
cp "$SRC/uninstall.sh" "$CFG/uninstall.sh" && chmod +x "$CFG/uninstall.sh"
ok "installed $BIN/cobra"

case ":$PATH:" in *":$BIN:"*) ;; *) export PATH="$BIN:$PATH";; esac

# ---- config (never overwritten on update) -----------------------------------------------------
# fresh install = clean defaults (old settings replaced, API key kept); --update keeps your settings
if [ "$UPDATE" = 0 ] || [ ! -f "$CFG/config.json" ]; then
    repo=""
    if [ -d "$SRC/.git" ] && command -v git >/dev/null 2>&1; then
        repo="$(git -C "$SRC" remote get-url origin 2>/dev/null || true)"
        case "$repo" in https://github.com/*) ;; git@github.com:*) repo="https://github.com/${repo#git@github.com:}" ;; *) repo="";; esac
    fi
    [ -n "${COBRA_REPO:-}" ] && repo="$COBRA_REPO"   # set by the one-line install (needed when installing from a zip)
    COBRA_REPO="$repo" python3 - "$CFG/config.json" <<'PY'
import json, os, sys
json.dump({"theme": "blood", "animation": "full", "model": "gemini-flash-lite-latest", "custom": "", "autoopen": "on", "quality": "pro", "phone": "off", "phone_ok": "", "multi": "team", "intro": "glitch", "custom2": "",
           "repo": os.environ.get("COBRA_REPO", "")}, open(sys.argv[1], "w"), indent=2)
PY
    [ -n "$repo" ] && ok "update source: $repo" || warn "update source not set (run: cobra set repo https://github.com/<you>/COBRA)"
fi

# ---- API key (optional here; you can also run:  cobra key <KEY>) -----------------------------------
if [ -n "$KEY" ]; then
    if printf '%s' "$KEY" | grep -Eq '^[A-Za-z0-9_.-]{20,}$'; then
        ( umask 077; printf '%s\n' "$KEY" > "$CFG/key" ); chmod 600 "$CFG/key" 2>/dev/null
        ok "API key saved (only on this device)"
    else
        warn "that API key looks wrong - set it later with: cobra key <KEY>"
    fi
elif [ -s "$CFG/key" ] || [ -s "$CFG/keys.json" ]; then
    ok "existing API key kept"
fi

# ---- 3. shell integration ---------------------------------------------------------------------
add_block() {  # file shell
    local file="$1" sh_name="$2"
    [ -f "$file" ] || touch "$file"
    if ! grep -q '# COBRA CONFIG START' "$file" && [ ! -f "$file.cobra.bak" ]; then cp -p "$file" "$file.cobra.bak"; fi
    sed -i '/# COBRA CONFIG START/,/# COBRA CONFIG END/d' "$file"
    cat >> "$file" <<EOF
# COBRA CONFIG START
export PATH="$BIN:\$PATH"
if [[ \$- == *i* ]] && [ -t 1 ] && command -v cobra >/dev/null 2>&1; then
  eval "\$(cobra init $sh_name)"
fi
# COBRA CONFIG END
EOF
    ok "updated $file"
}
add_block "$HOME/.bashrc" bash
if [ -f "$HOME/.zshrc" ] || command -v zsh >/dev/null 2>&1; then add_block "$HOME/.zshrc" zsh; fi

# ---- 4. Termux extras ---------------------------------------------------------------------------
: > "$MANIFEST.new"
echo "bin=$BIN/cobra" >> "$MANIFEST.new"
if [ "$IS_TERMUX" = 1 ]; then
    mkdir -p "$HOME/.termux"
    theme="$HOME/.termux/colors.properties"
    if [ -f "$theme" ] && ! cmp -s "$theme" "$SRC/extras/colors.properties"; then
        [ -f "$CFG/colors.properties.bak" ] || cp -p "$theme" "$CFG/colors.properties.bak"
    fi
    cp "$SRC/extras/colors.properties" "$theme"
    echo "colors=1" >> "$MANIFEST.new"
    if [ ! -f "$HOME/.hushlogin" ] || grep -q '^hush=1' "$MANIFEST" 2>/dev/null; then
        touch "$HOME/.hushlogin"; echo "hush=1" >> "$MANIFEST.new"
    fi
    command -v termux-reload-settings >/dev/null 2>&1 && termux-reload-settings 2>/dev/null
    ok "Termux theme installed"
    if ! { [ -d /sdcard ] && [ -w /sdcard ]; }; then
        warn "allow storage access in the popup (exports go to /sdcard/Cobra)"
        command -v termux-setup-storage >/dev/null 2>&1 && termux-setup-storage </dev/null >/dev/null 2>&1 || true
    fi
fi
mv "$MANIFEST.new" "$MANIFEST"

printf '\n'
"$BIN/cobra" banner --anim 2>/dev/null || true
printf ' %sDone.%s Open a new terminal session (or run: %ssource ~/.bashrc%s)\n\n' "$G" "$N" "$C" "$N"
printf '   %scobra%s     AI code engine      %shelp%s     all commands\n' "$C" "$N" "$C" "$N"
printf '   %sdoctor%s    test key/network    %stheme%s    change colors\n\n' "$C" "$N" "$C" "$N"
{ [ -s "$CFG/key" ] || [ -s "$CFG/keys.json" ]; } || printf '   %sNo API key yet:%s  cobra key add GEMINI_KEY GROK_KEY   (any provider, auto-detected)\n\n' "$Y" "$N"
