# COBRA changelog

## 1.5.0
- The AI now chooses the right technology: tools / bots / scanners / automation become real Python (or Node / shell) programs,
  games and visual apps stay web apps. If you name a language (python, html, node ...) that one is used.
- Multi-file projects: bigger builds are saved as a folder (main.py, modules, README.md ...), every file is checked and auto-repaired,
  the folder is exported to /sdcard/Cobra. `/run <n>` starts a project, `/open` shows it, `/edit <n>` changes it, `/undo` restores it,
  `/list` shows folders with a trailing `/`, delete/restore work on folders
- Team mode also reviews whole projects (a second AI checks every file)
- Premium terminal-tool quality rules (colour UI, argparse --help, retries, README, honest root/permission notes)
- Gemini: stronger `flash` model is tried first; when one model hits its free limit COBRA tries the next model on the same key

## 1.4.1
- 7 intro animations: glitch, matrix, typewriter, scan, rain, burst, mix (random each time)
- `cobra intro` plays all of them; `cobra intro NAME` or `cobra set intro NAME` keeps one
- Header / status lines fit narrow phone screens (no more broken lines)

## 1.4.0
- Unlimited API keys: auto-detect provider + best model per key (Gemini, OpenAI, Claude, Grok/xAI, OpenRouter, Groq, Mistral, DeepSeek, ...)
- Key details card on add; `key list/use/off/on/remove/test`; old single key is migrated automatically
- Team mode: second key reviews the first key's draft; automatic failover across keys and models
- New themes (hacker, venom, ember, neon, ice, gold ...), two-colour custom theme, matrix intro, sweep animation after commands

## 1.3.0
- Grey auto-suggestions while you type (from your history + built-in ideas): press Right arrow or Tab to accept
- Projects: numbered `/list`, `/delete <number|name|1,3|2-4|all>` (always asks, goes to trash), `/restore`, `/trash`
  - also from the shell: `cobra list`, `cobra delete`, `cobra restore`
- `/home` returns to the first screen and starts fresh (also /back /menu /close)
- Phone control mode (OFF by default): `/phone on|auto|off`. Shows every command first, risky ones always ask,
  deletes go to a trash folder, everything is logged in ~/.cobra/phone.log
- Builds are now "pro" quality by default (luxury UI, animations, saved data, real features); `cobra set quality fast` for short code
- Extra self-checks before delivering: every getElementById id must exist, Python imports must be installed

## 1.2.0
- New intro: banner decodes out of glitch symbols, shimmer, loading bars; every page header animates
- `cobra` opens on its own full page and gives the terminal back exactly as it was when you leave
- Animated gradient "working" bar while the AI thinks, per-step spinners, result summary (lines, KB, seconds)
- Theme menu shows a color swatch for every theme
- New engine commands: /undo (every edit is backed up, last 20 versions), /versions, /stats, /clear
- Animation default is `full` (use `cobra set animation short` or `off` for less)

## 1.1.2
- Fix: 'create ...' now always starts a NEW project (before, it edited the last file); edits keep working when you describe a change

## 1.1.1
- Default model is now gemini-flash-lite-latest (2.5 models are closed to new users); COBRA also asks Google for other working models and remembers the one that answers

## 1.1.0
- Red "blood" default theme, 7 themes + your own hex color (`theme #00aaff`), Termux colors follow the theme
- Every command opens on its own clean full-screen page (Enter = back)
- AI engine fixes: always shows what the model writes, live "thinking" spinner, auto retry,
  automatic fallback to other Gemini models, non-streaming fallback
- New: `doctor` (finds the exact reason when the AI does not answer), `cobra models`, `cobra key <KEY>`
- Finished HTML games/apps open automatically (`cobra set autoopen off` to disable)
- Installer: `--key`, installs nodejs (real JS syntax check), asks for storage permission

## 1.0.0
- Animated gradient banner with boot checks and 5 themes
- AI code engine: live streaming, auto-save, syntax check + auto-repair, colored diffs, export to /sdcard/Cobra
- Telegram menu: updates channel + developer chat
- Safe updates: `cobra update` shows what changes and asks first
