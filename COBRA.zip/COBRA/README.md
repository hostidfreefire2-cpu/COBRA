# COBRA

Animated terminal banner **+ AI code engine** for Termux and Linux.
Type what you want ("create a notepad"), COBRA writes the code live, saves it, checks it, fixes it if it
is broken, and exports it to your phone storage.

- Channel (all updates): https://t.me/cobratermux
- Developer: https://t.me/coderbhai_01

## Install (one command, paste once)

```bash
# Termux  (replace YOUR_USERNAME; add --key YOUR_GEMINI_KEY at the end to save your key right away)
pkg update -y && pkg install -y git python && rm -rf ~/COBRA && git clone https://github.com/YOUR_USERNAME/COBRA.git ~/COBRA && cd ~/COBRA && bash install.sh

# Debian / Ubuntu / Kali
sudo apt update && sudo apt install -y git python3 && rm -rf ~/COBRA && git clone https://github.com/YOUR_USERNAME/COBRA.git ~/COBRA && cd ~/COBRA && bash install.sh
```

Running it again later **replaces** the old install (fresh settings, your API key is kept).
Then close Termux completely and open it again. Allow the storage popup once (exports go to `/sdcard/Cobra`).

## First time: API key

Get a free key at https://aistudio.google.com/apikey, then:

```bash
cobra key add GEMINI_KEY GROK_KEY   # one or many keys at once - provider + model are auto-detected
cobra key list                      # all keys, provider, model, status
cobra doctor            # tests network + key + model, fixes the model automatically
cobra                   # start: type  create a notepad
```

**Never put your key inside the GitHub repo** - Google disables keys that are published.

## Multiple AI keys (v1.4.0)

- `cobra key add KEY [KEY ...]` (or `/key add ...` inside the engine). COBRA detects the provider from the key
  and the server, picks the best model, shows a details card. Supported: Gemini, OpenAI, Anthropic Claude,
  Grok (xAI, keys `xai-...`), OpenRouter, Groq, Mistral, DeepSeek, Together, Cerebras, NVIDIA, Perplexity,
  or any OpenAI-compatible server with `--url`.
- `cobra key list | use N | off N | on N | remove N | test`
- **1 key** = that key works alone. **2+ keys** = *team mode* (default): one key writes the draft, a different
  key reviews and improves it. This uses about twice the calls/quota. `cobra set multi failover` = keys are
  only used as automatic backups for each other.
- If a key hits its limit or fails, COBRA switches to the next key / model by itself.
- Themes: `cobra theme hacker`, or two colours `cobra theme #ff0033 #ffaa00`; intro animations: `cobra intro` (preview all) then `cobra set intro glitch|matrix|typewriter|scan|rain|burst|mix`.

## What it builds (v1.5.0)

COBRA picks the technology itself: `create a hotspot tool` -> a Python terminal program (with Termux:API where possible),
`create a snake game` -> a web game, big builds -> a multi-file project folder with README. Say `in python` / `in html` / `in node`
to force one. `/run 1` starts a project, `/edit 1` changes it, `/undo` goes back.

## Commands (each one opens on its own clean page, Enter = back)

| Command | What it does |
|---|---|
| `cobra` | AI code engine |
| `help` | command menu |
| `theme` | pick a theme or type any color: `theme #00aaff` (Termux window colors follow) |
| `doctor` | finds the exact reason when the AI does not answer |
| `cobra key <KEY>` | save the Gemini API key |
| `cobra models` | choose from the models your key can use |
| `channel` / `dev` / `report` | Telegram: updates, developer, send feedback |
| `update` | update COBRA (shows what changes, asks first) |
| `cobra set animation off\|short\|full` | animation level |
| `cobra set autoopen on\|off` | open finished HTML games/apps automatically |
| `cobra set quality pro\|fast` | pro = luxury, full-featured builds (default); fast = short code |
| `cobra list` / `cobra delete` / `cobra restore` / `cobra phone` | manage projects, phone control |
| `clear` / `clear n` | clear with banner / plain clear |
| `cobra uninstall` | remove everything COBRA added |

Themes: `blood` (default red), `venom`, `ember`, `neon`, `ice`, `gold`, `violet`, or any hex color.

### Inside the AI engine

Type a request in any language (English, Bangla, ...). With a file open, your next message edits it and
shows a red/green diff. If the model is busy or missing, COBRA retries and switches to another Gemini model.

`/new` `/paste` `/edit <file>` `/open` `/run` `/save <name>` `/list` `/export` `/undo` `/versions` `/stats` `/clear` `/key` `/model` `/models` `/theme` `/doctor` `/quit`

Start a new project by beginning with *create ...*; anything else edits the open file. Every edit is backed up, `/undo` brings the old version back.

Projects live in `~/cobra/projects`. Exports go to `/sdcard/Cobra` (Termux) or `~/cobra/exports`.


### Projects: list, delete, restore

`/list` shows a numbered list. `/delete 2`, `/delete notepad`, `/delete 1,3`, `/delete 2-4` or `/delete all`
(it always asks first; add `-y` to skip the question). Deleted files go to a trash folder, `/restore` brings them
back, `/trash` shows what is there, `/trash empty` removes it for good. The same works from the shell:
`cobra list`, `cobra delete all`, `cobra restore`. `/home` goes back to the first screen.

### Phone control (optional, OFF by default)

`/phone on` lets the AI run shell commands on **your own phone** inside Termux (open files, move or delete files,
run tools). You type what you want in plain words ("open my Download folder", "delete notepad.html").

- It shows every command before running it. `on` = asks every time, `auto` = runs ordinary commands, but anything
  risky (deleting, overwriting, network upload, private sensors) always asks.
- Deletes go to `~/.cobra/phone-trash`. Everything that ran is written to `~/.cobra/phone.log`.
- Turn off any time: `/phone off`. `/code` switches back to code mode without turning it off.
- Camera, battery, clipboard and similar need `pkg install termux-api` and the Termux:API app.
- Android still decides what Termux may touch; for `/sdcard` run `termux-setup-storage` once.
- Review the command shown on screen. The AI can be wrong, so do not use `auto` on files you cannot lose.

## Publishing updates to your users (developer guide)

1. Put this project in **your** GitHub repo. Users must install from your repo
   (`git clone` sets the update source automatically, or they run `cobra set repo <url>`).
2. Change the code, then edit `VERSION` (e.g. `1.0.1`), add notes at the top of `CHANGELOG.md`.
3. Optional announcement on every user's banner: edit `news.json`:
   `{ "message": "New theme added! Type: cobra theme" }`
4. `git push`. Within ~6 hours users see **"update available"** under their banner. They type `update`,
   see the changelog, and confirm.

Updates are **never silent and never auto-executed**: news is plain text that is only displayed, and
installing an update always needs the user to confirm.

## What touches the network

| When | Where | What |
|---|---|---|
| you send a request in the engine | Google Gemini API | your prompt (+ the open file when editing), your key in a header |
| banner, every 6 h | raw.githubusercontent.com (your repo) | `VERSION` and `news.json`, read-only |
| `update` | your GitHub repo | `git clone` after you confirm |
| `channel`, `dev`, `report` | Telegram | opens a link in your browser, nothing is sent for you |

No telemetry, no hidden servers, no tokens inside the code.

## Make it yours

- Name / tagline / links: top of `bin/cobra.py` (`TAGLINE`, `CHANNEL_URL`, `DEV_URL`)
- Colors: `THEMES` in `bin/cobra.py`; Termux palette: `extras/colors.properties`
- AI behavior: `SYSTEM_PROMPT` in `bin/cobra.py`
- Standard library only, one file, easy to read.

## License

MIT, see `LICENSE`.
