#!/usr/bin/env bash
# COBRA uninstaller. Removes only what install.sh added. Your projects in ~/cobra are never touched.
set -u
CFG="$HOME/.cobra"
MANIFEST="$CFG/manifest"
YES=0; [ "${1:-}" = "--yes" ] && YES=1
if [ -t 1 ]; then G=$'\e[1;92m'; Y=$'\e[1;93m'; N=$'\e[0m'; else G=""; Y=""; N=""; fi
ok()   { printf ' %s[+]%s %s\n' "$G" "$N" "$1"; }
warn() { printf ' %s[!]%s %s\n' "$Y" "$N" "$1"; }

if [ "$YES" != 1 ]; then
    printf '\n Remove COBRA (banner, prompt, command, settings)? Your projects stay. [y/N] '
    read -r ans; case "$ans" in y|Y|yes|YES) ;; *) echo " cancelled."; exit 0;; esac
fi

for rc in "$HOME/.bashrc" "$HOME/.zshrc"; do
    if [ -f "$rc" ] && grep -q '# COBRA CONFIG START' "$rc"; then
        cp -p "$rc" "$rc.cobra-uninstall.bak"
        sed -i '/# COBRA CONFIG START/,/# COBRA CONFIG END/d' "$rc"
        ok "removed COBRA block from $rc (backup: $rc.cobra-uninstall.bak)"
    fi
done

bin="$(grep '^bin=' "$MANIFEST" 2>/dev/null | head -n1 | cut -d= -f2-)"
[ -z "$bin" ] && bin="$(command -v cobra 2>/dev/null || true)"
if [ -n "$bin" ] && [ -f "$bin" ] && head -n12 "$bin" | grep -q 'COBRA'; then rm -f "$bin" && ok "removed $bin"; fi

if [ -d /data/data/com.termux/files/usr ]; then
    if [ -f "$CFG/colors.properties.bak" ]; then
        cp -p "$CFG/colors.properties.bak" "$HOME/.termux/colors.properties" && ok "restored your old Termux colors"
    elif grep -q '^colors=1' "$MANIFEST" 2>/dev/null; then
        rm -f "$HOME/.termux/colors.properties" && ok "removed COBRA colors"
    fi
    if grep -q '^hush=1' "$MANIFEST" 2>/dev/null; then rm -f "$HOME/.hushlogin" && ok "Termux welcome text restored"; fi
    command -v termux-reload-settings >/dev/null 2>&1 && termux-reload-settings 2>/dev/null
fi

if [ "$YES" = 1 ]; then ans=y; else printf ' Also delete settings and the saved API key in ~/.cobra? [y/N] '; read -r ans; fi
case "$ans" in y|Y|yes|YES) rm -rf "$CFG" && ok "removed ~/.cobra";; *) warn "kept ~/.cobra (settings, API key)";; esac
printf '\n %sCOBRA removed.%s Open a new terminal. Projects are still in ~/cobra\n\n' "$G" "$N"
